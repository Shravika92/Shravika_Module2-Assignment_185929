import { Injectable } from '@angular/core';
import { Emp } from './Emp';
@Injectable({
  providedIn: 'root'
})
export class EmpService {

  empList:Array<Emp>=[];
  constructor() { }
  setEmpDetails(emp:Emp){
    this.empList.push(emp);
  }
}
