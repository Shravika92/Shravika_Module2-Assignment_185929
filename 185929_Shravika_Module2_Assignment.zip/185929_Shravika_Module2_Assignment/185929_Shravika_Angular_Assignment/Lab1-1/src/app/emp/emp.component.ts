import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  emp:Emp = {
    id: null,
    name:" ",
    salary: null,
    department:" "
  };

  constructor() { }

  ngOnInit() {
  }
addEmp(id,name,salary,department){
  alert(`${id.value}  ${name.value}  ${salary.value} ${department.value}`);
}
}
